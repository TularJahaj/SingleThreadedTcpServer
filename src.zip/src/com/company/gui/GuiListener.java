package com.company.gui;

/**
 * Created by TularJahaj on 3/23/2017.
 */
public interface GuiListener {
    public void onClickSend( String s);

}
